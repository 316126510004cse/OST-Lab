#include<stdio.h>
int main()
{
int a[5],s,i,n;
printf("enter number of elements:");
scanf("%d",&n);
printf("enter the elements")
for(i=0;i<5;i++)
{
printf("the elements are:");
scanf("%d"&a[i]);
}
printf("enter the element to be searched:");
scanf("%d"&s);
if(a[i]==s)
{
printf("element is found");
}
else
{
printf("element is not found");
}
}
